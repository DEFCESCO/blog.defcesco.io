import pycurl
from scrapy.selector import Selector
from urllib.parse import urlparse

def get_links(page):
    return Selector(text=page).xpath('//a/@href').extract()

def get_images(page):
    return Selector(text=page).css('img').xpath('@src').extract()

def request(url):
    resp = ""
    try:
        c = pycurl.Curl()
        c.setopt(c.URL, url)
        c.setopt(c.TIMEOUT, 5)
        c.setopt(c.VERBOSE, True)
        c.setopt(c.FOLLOWLOCATION, True)

        resp = c.perform_rb().decode('utf-8', errors='ignore')
        c.close()
    finally:
        return resp

def get_base_url(url):
    parsed = urlparse(url)
    return "{0.scheme}://{0.netloc}".format(parsed)

def make_absolute(base, url):
    if url.startswith('//') or '://' in url:
        return url
    return "{0}{1}".format(base, url)

def make_absolute_list(base, urls):
    return [make_absolute(base, url) for url in urls]

def process_url(url):
    page = request(url)
    base = get_base_url(url)
    links = get_links(page)
    images = get_images(page)
    return make_absolute_list(base,links), make_absolute_list(base,images)

    