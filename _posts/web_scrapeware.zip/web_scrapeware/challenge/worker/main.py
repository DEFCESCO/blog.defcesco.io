import redis, pickle, time, base64
from scrape import process_url

config = {
    'REDIS_HOST' : '127.0.0.1',
    'REDIS_PORT' : 6379,
    'REDIS_JOBS' : 'jobs',
    'REDIS_QUEUE' : 'jobqueue',
    'REDIS_RESULTS' : 'results',
    'REDIS_NUM_JOBS' : 0
}

def env(key):
    val = False
    try:
        val = config[key]
    finally:
        return val

store = redis.StrictRedis(host=env('REDIS_HOST'), port=env('REDIS_PORT'), db=0)

def get_work_item():
    job_id = store.rpop(env('REDIS_QUEUE'))
    if not job_id:
        return False

    data = store.hget(env('REDIS_JOBS'), job_id)

    job = pickle.loads(base64.b64decode(data))
    return job

def incr_field(job, field):
    job[field] = job[field] + 1
    store.hset(env('REDIS_JOBS'), job['job_id'], base64.b64encode(pickle.dumps(job)))

def decr_field(job, field):
    job[field] = job[field] - 1
    store.hset(env('REDIS_JOBS'), job['job_id'], base64.b64encode(pickle.dumps(job)))

def update_results(job, images, visited):
    job_id = job['job_id']
    result_key = '{0}:{1}'.format(env('REDIS_RESULTS'), job_id)
    for img in images:
        if img in visited:
            continue

        visited.add(img)
        store.rpush(result_key, img)

def run_worker():
    job = get_work_item()
    if not job:
        return

    incr_field(job, 'inprogress')

    urls = job['urls'][:]
    maxlevel = 1
    output = []
    visited = set()
    imgvisited = set()

    for _ in range(maxlevel):
        if not urls:
            break

        next_urls = []
        for url in urls:
            if url in visited:
                continue

            visited.add(url)
            links, images = process_url(url)
            next_urls += links

            update_results(job, images, imgvisited)

        urls = next_urls

    incr_field(job, 'completed')
    decr_field(job, 'inprogress')

if __name__ == '__main__':
    while True:
        time.sleep(10)
        run_worker()
