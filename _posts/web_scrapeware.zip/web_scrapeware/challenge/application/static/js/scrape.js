$(document).ready(() => {
    load_scrape_jobs();
	$('#add-scrape-job').on('click', add_scrape_job);
});

const add_scrape_job = async () => {

	let card = $('#resp-msg');
	card.attr('class', 'alert alert-info');
	card.hide();

	let job_title = $('#job_title').val();
	let urls = $('#urls').val();

    urls = urls.split('\n')

	await fetch('/api/admin/scrape/create', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
                job_title,
                urls
            }),
		})
		.then((response) => response.json()
			.then((resp) => {
				card.attr('class', 'alert alert-danger');

				if (response.status == 200) {
					location.reload();
				}

				card.text(resp.message);
				card.show();
			}))
		.catch((error) => {
			card.text(error);
			card.attr('class', 'alert alert-danger');
			card.show();
		});

}

const load_scrape_jobs = async () => {

	await fetch('/api/admin/scrape/list', {
			method: 'GET',
			credentials: 'include'
		})
		.then((response) => response.json()
			.then((scrape_list) => {
				if (scrape_list.length) {
                    scrape_list.forEach(job_id => {
                        fetch_job_queue(job_id);
                    });
                }
			}))
		.catch((error) => {
			card.text(error);
			card.attr('class', 'alert alert-danger');
			card.show();
		});

}

const fetch_job_queue = async (job_id) => {

    await fetch(`/api/admin/scrape/${job_id}/status`, {
        method: 'GET',
        credentials: 'include'
    })
    .then((response) => response.json()
        .then((job_data) => {
            if (job_data.hasOwnProperty('job_id')) {
                populate_job_card(job_data)
            }
        }))
    .catch((error) => {
        console.log(error);
    });
}

const fetch_job_result = async (job_id) => {

    return await fetch(`/api/admin/scrape/${job_id}/result`, {
        method: 'GET',
        credentials: 'include'
    })
    .then((response) => response.json()
        .then((result_list) => {
            return result_list;
        }))
    .catch((error) => {
        console.log(error);
        return false;
    });
}

const populate_job_card = async (job_data) => {
    let result = false;
    let resultHTML = '';

    if (job_data.in_progress == 1) {
        job_status = 'In Progress';
    }
    else if (job_data.completed == 1) {
        job_status = 'Completed';
        result = await fetch_job_result(job_data.job_id);
    }
    else {
        job_status = 'In Queue';
    }

    if (result) {
        resultHTML = `
            <p class="card-text mt-3">Results</p>
            <textarea type="text" class="form-control w-100 mt-3" style="height: 200px;" placeholder="Result">${result.join('\n')}</textarea>
        `;
    }

    cardHTML = `
        <div class="card mt-5">
            <div class="card-header">test</div>
            <div class="card-body">
                <p class="card-title">${job_data.job_id} : ${job_data.job_title}</p>
                <p class="card-text">Status: ${job_status}</p>
                <textarea type="text" class="form-control w-100" style="height: 200px;" placeholder="URL List">${job_data.urls.join('\n')}</textarea>
                ${resultHTML}
            </div>
        </div>
    `;

    $('#jobs-container').append(cardHTML);
}