$(document).ready(function() {
	$('#request-btn').on('click', requestQuote);
});

const requestQuote = async () => {
	$('#request-btn').prop('disabled', true);

	let card = $("#resp-msg");
	card.attr("class", "alert alert-info");
	card.text("Submitting your request, please wait...");
	card.show();

	let params = {
        'name': $('#name').val(),
        'email_address': $('#email-address').val(),
        'company_name': $('#company-name').val(),
        'company_size': $('#company-size').val(),
        'quote_message': $('#quote-message').val()
    }

	await fetch(`/api/request-quote`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(params),
		})
		.then((response) => response.json()
			.then((resp) => {
				if (response.status == 200) {
					card.attr("class", "alert alert-info");
				} else {
                    card.attr("class", "alert alert-danger");
                }

                card.text(resp.message);
                card.show();
			})
        )
		.catch((error) => {
			card.text(error);
			card.attr("class", "alert alert-danger");
			card.show();
            $('#request-btn').prop('disabled', false);
		});

    $('#request-btn').prop('disabled', false);
}