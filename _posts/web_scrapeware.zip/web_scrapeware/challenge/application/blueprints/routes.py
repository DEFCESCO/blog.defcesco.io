import json
from application.database import User, QuoteRequests, db, clear_requests
from flask import Blueprint, Response, jsonify, redirect, render_template, request
from flask_login import login_required, login_user, logout_user
from application.bot import view_requests
from application.cache import get_job_list, create_job_queue, get_job_queue, get_job_result

web = Blueprint('web', __name__)
api = Blueprint('api', __name__)

def response(message, status=200):
    return jsonify({'message': message}), status

@web.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@api.route('/request-quote', methods=['POST'])
def request_quote():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()

    contact_name  = data.get('name', '')
    email_address = data.get('email_address', '')
    quote_message = data.get('quote_message', '')
    company_name  = data.get('company_name', '')
    company_size  = data.get('company_size', '')

    if not email_address or not quote_message:
        return response('Missing required parameters!', 401)

    quote_request = QuoteRequests(
        name=contact_name,
        email_address=email_address,
        quote_message=quote_message,
        company_name=company_name,
        company_size=company_size
    )

    db.session.add(quote_request)
    db.session.commit()

    view_requests()
    clear_requests()

    return response('Request received successfully!')

@web.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

@api.route('/login', methods=['POST'])
def user_login():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')

    if not username or not password:
        return response('Missing required parameters!', 401)

    user = User.query.filter_by(username=username).first()

    if not user or not user.password == password:
        return response('Invalid username or password!', 403)

    login_user(user)
    return response('User authenticated successfully!')

@web.route('/admin/quote-requests')
@login_required
def dashboard():
    quote_requests = QuoteRequests.query.all()
    return render_template('requests.html', requests=quote_requests)

@web.route('/admin/scrape')
@login_required
def scrape_list():
    quote_requests = QuoteRequests.query.all()
    return render_template('scrape.html', requests=quote_requests)


@api.route('/admin/scrape/list', methods=['GET'])
@login_required
def job_list():
    data = get_job_list()

    if not data:
        return Response(json.dumps([]), mimetype='application/json')

    return Response(json.dumps(data), mimetype='application/json')


@api.route('/admin/scrape/create', methods=['POST'])
@login_required
def job_create():
    if not request.is_json:
        return response('Missing required parameters!', 401)

    data = request.get_json()

    urls = data.get('urls', [])
    job_title = data.get('job_title', '')

    if not type(urls) == list or not urls or not job_title:
        return response('Missing required parameters!', 401)

    data = create_job_queue(urls, job_title)

    return Response(json.dumps(data), mimetype='application/json')

@api.route('/admin/scrape/<int:job_id>/status', methods=['GET'])
@login_required
def job_status(job_id):
    data = get_job_queue(job_id)

    if not data:
        return response('Job does not exist!', 401)

    return Response(json.dumps(data), mimetype='application/json')

@api.route('/admin/scrape/<int:job_id>/result', methods=['GET'])
@login_required
def job_result(job_id):
    data = get_job_result(job_id)

    if not data:
        return response('Result does not exist!', 401)

    return Response(json.dumps(data), mimetype='application/json')

@web.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')
