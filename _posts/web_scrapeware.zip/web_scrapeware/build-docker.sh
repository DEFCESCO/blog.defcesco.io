#!/bin/bash
docker build --tag=web_scrapeware .
docker run -p 1337:1337 --rm \
    -v "$(pwd)/challenge/application:/app/application" \
    -v "$(pwd)/challenge/worker:/app/worker" \
    --name=web_scrapeware web_scrapeware